const config = require('../app/config.json');

// Pop a lil' monogram in the terminal
console.info(config.ascii);
